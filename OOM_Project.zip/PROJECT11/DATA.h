#ifndef _data_
#define _data_
#include <string>
using namespace std;

namespace project
{
    class Data
    {
    public:
        void SEARCH_hindiM(int);
        void SEARCH_englishM(int);
        void SEARCH_hindiw(int);
        void SEARCH_englishw(int);
        void seasons_(string);
        void rating_(string);
    };
}
#endif